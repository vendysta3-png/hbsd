import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import type { Tables, TablesInsert, TablesUpdate } from '@/integrations/supabase/types';

export type RetourColis = Tables<'retours_colis'>;
export type RetourColisInsert = TablesInsert<'retours_colis'>;
export type RetourColisUpdate = TablesUpdate<'retours_colis'>;

export function useRetours() {
  return useQuery({
    queryKey: ['retours_colis'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('retours_colis')
        .select('*')
        .order('date_heure_saisie', { ascending: false });
      if (error) throw error;
      return data as RetourColis[];
    },
  });
}

export function useCreateRetour() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async (retour: RetourColisInsert) => {
      const { data, error } = await supabase.from('retours_colis').insert(retour).select().single();
      if (error) throw error;
      return data;
    },
    onSuccess: () => qc.invalidateQueries({ queryKey: ['retours_colis'] }),
  });
}

export function useBatchCreateRetours() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async (retours: RetourColisInsert[]) => {
      const CHUNK = 500;
      let inserted = 0;
      for (let i = 0; i < retours.length; i += CHUNK) {
        const chunk = retours.slice(i, i + CHUNK);
        const { error } = await supabase.from('retours_colis').insert(chunk);
        if (error) throw error;
        inserted += chunk.length;
      }
      return inserted;
    },
    onSuccess: () => qc.invalidateQueries({ queryKey: ['retours_colis'] }),
  });
}

export function useUpdateRetour() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async ({ id, ...updates }: RetourColisUpdate & { id: string }) => {
      const { data, error } = await supabase.from('retours_colis').update(updates).eq('id', id).select().single();
      if (error) throw error;
      return data;
    },
    onSuccess: () => qc.invalidateQueries({ queryKey: ['retours_colis'] }),
  });
}

export function useDeleteRetour() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.from('retours_colis').delete().eq('id', id);
      if (error) throw error;
    },
    onSuccess: () => qc.invalidateQueries({ queryKey: ['retours_colis'] }),
  });
}
