import { useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useQueryClient } from '@tanstack/react-query';
import { toast } from 'sonner';

export function useRealtimeRetours() {
  const qc = useQueryClient();

  useEffect(() => {
    const channel = supabase
      .channel('retours-realtime')
      .on(
        'postgres_changes',
        { event: 'INSERT', schema: 'public', table: 'retours_colis' },
        (payload) => {
          qc.invalidateQueries({ queryKey: ['retours_colis'] });
          const row = payload.new as any;
          toast.info(`Nouveau retour : ${row.expediteur}`, {
            description: `Emplacement: ${row.emplacement} — Quantité: ${row.quantite}`,
          });
        }
      )
      .on(
        'postgres_changes',
        { event: 'UPDATE', schema: 'public', table: 'retours_colis' },
        () => {
          qc.invalidateQueries({ queryKey: ['retours_colis'] });
        }
      )
      .on(
        'postgres_changes',
        { event: 'DELETE', schema: 'public', table: 'retours_colis' },
        () => {
          qc.invalidateQueries({ queryKey: ['retours_colis'] });
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [qc]);
}
