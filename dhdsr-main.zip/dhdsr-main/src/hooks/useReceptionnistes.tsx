import { useState, useEffect } from 'react';

const STORAGE_KEY = 'l-retour-receptionnistes';
const DEFAULT_LIST = ['Mourad', 'Rahim', 'Amine', 'Salim'];

export function useReceptionnistes() {
  const [list, setList] = useState<string[]>(() => {
    try {
      const stored = localStorage.getItem(STORAGE_KEY);
      return stored ? JSON.parse(stored) : DEFAULT_LIST;
    } catch {
      return DEFAULT_LIST;
    }
  });

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(list));
  }, [list]);

  const add = (name: string) => {
    const trimmed = name.trim();
    if (trimmed && !list.includes(trimmed)) {
      setList(prev => [...prev, trimmed]);
    }
  };

  const remove = (name: string) => {
    setList(prev => prev.filter(n => n !== name));
  };

  return { receptionnistes: list, addReceptionniste: add, removeReceptionniste: remove };
}
