import { SidebarTrigger } from '@/components/ui/sidebar';
import { useAuth } from '@/hooks/useAuth';
import { useRetours } from '@/hooks/useRetours';
import { useRealtimeRetours } from '@/hooks/useRealtimeRetours';
import StatsCards from '@/components/StatsCards';
import ThemeToggle from '@/components/ThemeToggle';
import { Button } from '@/components/ui/button';
import { LogOut, Package, Clock } from 'lucide-react';
import { format } from 'date-fns';
import { fr } from 'date-fns/locale';

export default function DashboardHome() {
  const { signOut, user } = useAuth();
  const { data: retours = [], isLoading } = useRetours();
  useRealtimeRetours();

  return (
    <div className="min-h-screen bg-background">
      <header className="no-print sticky top-0 z-10 border-b" style={{ background: 'hsl(var(--header-bg))', color: 'hsl(var(--header-fg))' }}>
        <div className="mx-auto flex h-14 max-w-7xl items-center justify-between px-4">
          <div className="flex items-center gap-2 sm:gap-3">
            <SidebarTrigger className="text-inherit" />
            <div className="flex h-8 w-8 items-center justify-center rounded-md bg-white/20">
              <Package className="h-4 w-4 text-white" />
            </div>
            <h1 className="text-base font-semibold sm:text-lg">Gestion des retours</h1>
          </div>
          <div className="flex items-center gap-2 sm:gap-3">
            <span className="hidden text-sm opacity-80 md:block">{user?.email}</span>
            <ThemeToggle />
            <Button variant="ghost" size="sm" className="btn-press text-inherit hover:bg-white/20" onClick={signOut}>
              <LogOut className="h-4 w-4 sm:mr-2 text-red-400" />
              <span className="hidden sm:inline">Déconnexion</span>
            </Button>
          </div>
        </div>
      </header>

      <main className="mx-auto max-w-7xl space-y-6 p-4 md:p-6">
        <div>
          <h2 className="text-xl font-bold text-foreground sm:text-2xl">Tableau de bord</h2>
          <p className="text-sm text-muted-foreground">Vue d'ensemble des retours de colis</p>
        </div>

        {isLoading ? (
          <div className="card-surface flex h-64 items-center justify-center">
            <p className="text-muted-foreground">Chargement...</p>
          </div>
        ) : (
          <>
            <StatsCards data={retours} />

            <div className="card-surface p-4">
              <div className="flex items-center gap-2 mb-4">
                <Clock className="h-5 w-5 text-blue-500" />
                <h3 className="text-lg font-semibold text-foreground">Retours récents</h3>
              </div>
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="border-b bg-muted/50">
                      <th className="px-3 py-2 text-left text-xs font-medium uppercase tracking-wider text-muted-foreground">Date</th>
                      <th className="px-3 py-2 text-left text-xs font-medium uppercase tracking-wider text-muted-foreground">Expéditeur</th>
                      <th className="px-3 py-2 text-left text-xs font-medium uppercase tracking-wider text-muted-foreground">Quantité</th>
                      <th className="px-3 py-2 text-left text-xs font-medium uppercase tracking-wider text-muted-foreground">Emplac.</th>
                      <th className="px-3 py-2 text-left text-xs font-medium uppercase tracking-wider text-muted-foreground">État</th>
                    </tr>
                  </thead>
                  <tbody>
                    {retours.slice(0, 10).map(r => (
                      <tr key={r.id} className="border-b last:border-0 hover:bg-muted/30 transition-colors">
                        <td className="px-3 py-2 text-muted-foreground">
                          {format(new Date(r.date_heure_saisie), 'dd/MM/yyyy HH:mm', { locale: fr })}
                        </td>
                        <td className="px-3 py-2 font-medium">{r.expediteur}</td>
                        <td className="px-3 py-2 font-mono tabular-nums">{r.quantite}</td>
                        <td className="px-3 py-2 font-mono">{r.emplacement}</td>
                        <td className="px-3 py-2">
                          <span className={r.etat === 'Disponible' ? 'badge-available' : 'badge-recovered'}>
                            {r.etat}
                          </span>
                        </td>
                      </tr>
                    ))}
                    {retours.length === 0 && (
                      <tr>
                        <td colSpan={5} className="py-8 text-center text-muted-foreground">Aucun retour enregistré</td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          </>
        )}
      </main>
    </div>
  );
}
