import { useState } from 'react';
import { SidebarTrigger } from '@/components/ui/sidebar';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { useIsAdmin, adminAction } from '@/hooks/useAdmin';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Package, Plus, Trash2, Shield, User, Pencil } from 'lucide-react';
import ThemeToggle from '@/components/ThemeToggle';
import { useAuth } from '@/hooks/useAuth';
import { toast } from 'sonner';

type UserRecord = { id: string; email: string; created_at: string; role: string };

export default function UsersPage() {
  const { user, signOut } = useAuth();
  const { data: isAdmin, isLoading: adminLoading } = useIsAdmin();
  const qc = useQueryClient();
  const [createOpen, setCreateOpen] = useState(false);
  const [editOpen, setEditOpen] = useState(false);
  const [editUser, setEditUser] = useState<UserRecord | null>(null);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [role, setRole] = useState<string>('user');
  const [creating, setCreating] = useState(false);
  const [updating, setUpdating] = useState(false);
  const [selectedId, setSelectedId] = useState<string | null>(null);

  const { data: users = [], isLoading } = useQuery({
    queryKey: ['admin_users'],
    enabled: !!isAdmin,
    queryFn: async () => {
      const res = await adminAction('list');
      return res.users as UserRecord[];
    },
  });

  const resetForm = () => {
    setEmail('');
    setPassword('');
    setRole('user');
  };

  const handleCreate = async () => {
    if (!email || !password) return;
    setCreating(true);
    try {
      await adminAction('create', { email, password, role });
      toast.success('Utilisateur créé avec succès');
      resetForm();
      setCreateOpen(false);
      qc.invalidateQueries({ queryKey: ['admin_users'] });
    } catch (err: any) {
      toast.error(err.message);
    }
    setCreating(false);
  };

  const handleEdit = (u: UserRecord) => {
    setEditUser(u);
    setEmail(u.email);
    setPassword('');
    setRole(u.role);
    setEditOpen(true);
  };

  const handleUpdate = async () => {
    if (!editUser) return;
    setUpdating(true);
    try {
      const payload: Record<string, any> = { user_id: editUser.id };
      if (email !== editUser.email) payload.email = email;
      if (password) payload.password = password;
      if (role !== editUser.role) payload.role = role;
      await adminAction('update', payload);
      toast.success('Utilisateur mis à jour');
      setEditOpen(false);
      setEditUser(null);
      resetForm();
      qc.invalidateQueries({ queryKey: ['admin_users'] });
    } catch (err: any) {
      toast.error(err.message);
    }
    setUpdating(false);
  };

  const handleDelete = async (userId: string) => {
    if (!confirm('Supprimer cet utilisateur ?')) return;
    try {
      await adminAction('delete', { user_id: userId });
      toast.success('Utilisateur supprimé');
      qc.invalidateQueries({ queryKey: ['admin_users'] });
    } catch (err: any) {
      toast.error(err.message);
    }
  };

  if (adminLoading) return <div className="flex min-h-screen items-center justify-center"><p className="text-muted-foreground">Chargement...</p></div>;
  if (!isAdmin) return <div className="flex min-h-screen items-center justify-center"><p className="text-muted-foreground">Accès refusé. Seuls les administrateurs peuvent accéder à cette page.</p></div>;

  return (
    <div className="min-h-screen bg-background">
      <header className="no-print sticky top-0 z-10 border-b" style={{ background: 'hsl(var(--header-bg))', color: 'hsl(var(--header-fg))' }}>
        <div className="mx-auto flex h-14 max-w-7xl items-center justify-between px-4">
          <div className="flex items-center gap-3">
            <SidebarTrigger className="text-inherit" />
            <div className="flex h-8 w-8 items-center justify-center rounded-md bg-white/20">
              <Package className="h-4 w-4 text-white" />
            </div>
            <h1 className="text-base font-semibold sm:text-lg">Gestion d'utilisateurs</h1>
          </div>
          <ThemeToggle />
        </div>
      </header>

      <main className="mx-auto max-w-4xl space-y-6 p-4 md:p-6">
        <div className="flex items-center justify-between">
          <h2 className="text-xl font-bold text-foreground sm:text-2xl">Utilisateurs</h2>
          <Button onClick={() => { resetForm(); setCreateOpen(true); }}>
            <Plus className="mr-2 h-4 w-4 text-white" />
            Créer un utilisateur
          </Button>
        </div>

        {isLoading ? (
          <p className="text-muted-foreground">Chargement...</p>
        ) : (
          <div className="card-surface overflow-hidden">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Email</TableHead>
                  <TableHead>Rôle</TableHead>
                  <TableHead>Créé le</TableHead>
                  <TableHead className="w-24 text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {users.map(u => (
                  <TableRow
                    key={u.id}
                    className={`cursor-pointer transition-colors ${selectedId === u.id ? 'bg-blue-100 dark:bg-blue-900/30' : 'hover:bg-muted/50'}`}
                    onClick={() => setSelectedId(selectedId === u.id ? null : u.id)}
                  >
                    <TableCell className="font-medium">{u.email}</TableCell>
                    <TableCell>
                      <span className={`inline-flex items-center gap-1 rounded-full px-2.5 py-0.5 text-xs font-medium ${u.role === 'admin' ? 'bg-primary/10 text-primary' : 'bg-muted text-muted-foreground'}`}>
                        {u.role === 'admin' ? <Shield className="h-3 w-3 text-orange-500" /> : <User className="h-3 w-3 text-blue-500" />}
                        {u.role === 'admin' ? 'Admin' : 'Utilisateur'}
                      </span>
                    </TableCell>
                    <TableCell className="text-sm text-muted-foreground">
                      {new Date(u.created_at).toLocaleDateString('fr-FR')}
                    </TableCell>
                    <TableCell>
                      <div className="flex justify-end gap-1">
                        {u.id !== user?.id && (
                          <>
                            <Button variant="ghost" size="sm" onClick={(e) => { e.stopPropagation(); handleEdit(u); }}>
                              <Pencil className="h-4 w-4 text-blue-500" />
                            </Button>
                            <Button variant="ghost" size="sm" onClick={(e) => { e.stopPropagation(); handleDelete(u.id); }} className="text-destructive hover:text-destructive">
                              <Trash2 className="h-4 w-4 text-red-500" />
                            </Button>
                          </>
                        )}
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        )}
      </main>

      {/* Create Dialog */}
      <Dialog open={createOpen} onOpenChange={setCreateOpen}>
        <DialogContent className="max-w-sm">
          <DialogHeader>
            <DialogTitle>Créer un utilisateur</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div className="space-y-2">
              <Label>Email</Label>
              <Input value={email} onChange={e => setEmail(e.target.value)} placeholder="email@example.com" />
            </div>
            <div className="space-y-2">
              <Label>Mot de passe</Label>
              <Input type="password" value={password} onChange={e => setPassword(e.target.value)} placeholder="••••••••" minLength={6} />
            </div>
            <div className="space-y-2">
              <Label>Rôle</Label>
              <Select value={role} onValueChange={setRole}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="user">Utilisateur</SelectItem>
                  <SelectItem value="admin">Administrateur</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <Button className="w-full" onClick={handleCreate} disabled={creating || !email || !password}>
              {creating ? '...' : 'Créer'}
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* Edit Dialog */}
      <Dialog open={editOpen} onOpenChange={(open) => { setEditOpen(open); if (!open) setEditUser(null); }}>
        <DialogContent className="max-w-sm">
          <DialogHeader>
            <DialogTitle>Modifier l'utilisateur</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div className="space-y-2">
              <Label>Email</Label>
              <Input value={email} onChange={e => setEmail(e.target.value)} placeholder="email@example.com" />
            </div>
            <div className="space-y-2">
              <Label>Nouveau mot de passe <span className="text-xs text-muted-foreground">(laisser vide pour ne pas changer)</span></Label>
              <Input type="password" value={password} onChange={e => setPassword(e.target.value)} placeholder="••••••••" minLength={6} />
            </div>
            <div className="space-y-2">
              <Label>Rôle</Label>
              <Select value={role} onValueChange={setRole}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="user">Utilisateur</SelectItem>
                  <SelectItem value="admin">Administrateur</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <Button className="w-full" onClick={handleUpdate} disabled={updating}>
              {updating ? '...' : 'Mettre à jour'}
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
