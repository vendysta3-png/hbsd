import { useState, useRef } from 'react';
import { SidebarTrigger } from '@/components/ui/sidebar';
import { useIsAdmin, adminAction } from '@/hooks/useAdmin';
import { useQueryClient } from '@tanstack/react-query';
import { Button } from '@/components/ui/button';
import { Package, Download, Upload, Trash2, AlertTriangle } from 'lucide-react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import ThemeToggle from '@/components/ThemeToggle';
import { toast } from 'sonner';

export default function SettingsPage() {
  const { data: isAdmin, isLoading: adminLoading } = useIsAdmin();
  const qc = useQueryClient();
  const [clearOpen, setClearOpen] = useState(false);
  const [clearing, setClearing] = useState(false);
  const [restoring, setRestoring] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);

  const handleBackup = async () => {
    try {
      const res = await adminAction('backup');
      const blob = new Blob([JSON.stringify(res.data, null, 2)], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `backup-retours-${new Date().toISOString().slice(0, 10)}.json`;
      a.click();
      URL.revokeObjectURL(url);
      toast.success('Sauvegarde téléchargée');
    } catch (err: any) {
      toast.error(err.message);
    }
  };

  const handleRestore = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setRestoring(true);
    try {
      const text = await file.text();
      const records = JSON.parse(text);
      if (!Array.isArray(records)) throw new Error('Format invalide');
      await adminAction('restore', { records });
      toast.success(`${records.length} enregistrement(s) restauré(s)`);
      qc.invalidateQueries({ queryKey: ['retours_colis'] });
    } catch (err: any) {
      toast.error(err.message);
    }
    setRestoring(false);
    if (fileRef.current) fileRef.current.value = '';
  };

  const handleClear = async () => {
    setClearing(true);
    try {
      await adminAction('clear_data');
      toast.success('Toutes les données ont été effacées');
      qc.invalidateQueries({ queryKey: ['retours_colis'] });
      setClearOpen(false);
    } catch (err: any) {
      toast.error(err.message);
    }
    setClearing(false);
  };

  if (adminLoading) return <div className="flex min-h-screen items-center justify-center"><p className="text-muted-foreground">Chargement...</p></div>;
  if (!isAdmin) return <div className="flex min-h-screen items-center justify-center"><p className="text-muted-foreground">Accès refusé. Seuls les administrateurs peuvent accéder à cette page.</p></div>;

  return (
    <div className="min-h-screen bg-background">
      <header className="no-print sticky top-0 z-10 border-b" style={{ background: 'hsl(var(--header-bg))', color: 'hsl(var(--header-fg))' }}>
        <div className="mx-auto flex h-14 max-w-7xl items-center justify-between px-4">
          <div className="flex items-center gap-3">
            <SidebarTrigger className="text-inherit" />
            <div className="flex h-8 w-8 items-center justify-center rounded-md bg-white/20">
              <Package className="h-4 w-4" />
            </div>
            <h1 className="text-lg font-semibold">Paramètres</h1>
          </div>
          <ThemeToggle />
        </div>
      </header>

      <main className="mx-auto max-w-2xl space-y-6 p-4 md:p-6">
        <h2 className="text-2xl font-bold text-foreground">Paramètres</h2>

        {/* Backup & Restore */}
        <div className="card-surface p-6 space-y-4">
          <h3 className="text-lg font-semibold text-foreground">Sauvegarde et restauration</h3>
          <p className="text-sm text-muted-foreground">Téléchargez une sauvegarde de vos données ou restaurez à partir d'un fichier.</p>
          <div className="flex gap-3">
            <Button variant="outline" onClick={handleBackup}>
              <Download className="mr-2 h-4 w-4" />
              Sauvegarder
            </Button>
            <Button variant="outline" onClick={() => fileRef.current?.click()} disabled={restoring}>
              <Upload className="mr-2 h-4 w-4" />
              {restoring ? 'Restauration...' : 'Restaurer'}
            </Button>
            <input ref={fileRef} type="file" accept=".json" className="hidden" onChange={handleRestore} />
          </div>
        </div>

        {/* Clear data */}
        <div className="card-surface border-destructive/20 p-6 space-y-4">
          <h3 className="text-lg font-semibold text-foreground">Zone dangereuse</h3>
          <p className="text-sm text-muted-foreground">Effacer toutes les données de retours. Les utilisateurs ne seront pas affectés.</p>
          <Button variant="destructive" onClick={() => setClearOpen(true)}>
            <Trash2 className="mr-2 h-4 w-4" />
            Effacer toutes les données
          </Button>
        </div>
      </main>

      <Dialog open={clearOpen} onOpenChange={setClearOpen}>
        <DialogContent className="max-w-sm">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <AlertTriangle className="h-5 w-5 text-destructive" />
              Confirmer la suppression
            </DialogTitle>
            <DialogDescription>
              Cette action est irréversible. Toutes les données de retours seront supprimées définitivement. Les comptes utilisateurs ne seront pas affectés.
            </DialogDescription>
          </DialogHeader>
          <div className="flex gap-3 pt-2">
            <Button variant="outline" className="flex-1" onClick={() => setClearOpen(false)}>Annuler</Button>
            <Button variant="destructive" className="flex-1" onClick={handleClear} disabled={clearing}>
              {clearing ? '...' : 'Supprimer tout'}
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
