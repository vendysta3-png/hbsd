import { useState, useRef } from 'react';
import { SidebarTrigger } from '@/components/ui/sidebar';
import { useAuth } from '@/hooks/useAuth';
import { useRetours, useCreateRetour, useBatchCreateRetours, type RetourColis } from '@/hooks/useRetours';
import { useRealtimeRetours } from '@/hooks/useRealtimeRetours';
import { useReceptionnistes } from '@/hooks/useReceptionnistes';
import { useIsAdmin } from '@/hooks/useAdmin';
import { Progress } from '@/components/ui/progress';
import RetourTable from '@/components/RetourTable';
import RetourForm from '@/components/RetourForm';
import PrintDialog from '@/components/PrintDialog';
import ReceptionnistesDialog from '@/components/ReceptionnistesDialog';
import ThemeToggle from '@/components/ThemeToggle';
import { exportExcel, exportCSV, exportPDF, importFile } from '@/lib/exportUtils';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import {
  Plus, Download, Upload, Printer, LogOut, Search, FileSpreadsheet, FileText, FileDown, Package, Users,
} from 'lucide-react';
import {
  DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { toast } from 'sonner';

export default function RetoursPage() {
  const { signOut, user } = useAuth();
  const { data: retours = [], isLoading } = useRetours();
  useRealtimeRetours();
  const { receptionnistes, addReceptionniste, removeReceptionniste } = useReceptionnistes();
  const { data: isAdmin } = useIsAdmin();
  const createRetour = useCreateRetour();
  const batchCreate = useBatchCreateRetours();
  const [formOpen, setFormOpen] = useState(false);
  const [editData, setEditData] = useState<RetourColis | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState('Tous');
  const [importProgress, setImportProgress] = useState<number | null>(null);
  const [printOpen, setPrintOpen] = useState(false);
  const [recepDialogOpen, setRecepDialogOpen] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const filteredForExport = retours.filter(r => {
    if (statusFilter !== 'Tous' && r.etat !== statusFilter) return false;
    if (searchQuery) {
      const q = searchQuery.toLowerCase();
      if (!r.expediteur.toLowerCase().includes(q) && !(r.etat && r.etat.toLowerCase().includes(q))) return false;
    }
    return true;
  });

  const handleEdit = (retour: RetourColis) => { setEditData(retour); setFormOpen(true); };
  const handleAdd = () => { setEditData(null); setFormOpen(true); };

  const handleImport = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    try {
      setImportProgress(0);
      const rows = await importFile(file);
      const valid = rows.filter(r => r.expediteur && r.quantite && r.emplacement).map(r => ({
        expediteur: r.expediteur!, quantite: r.quantite!, emplacement: r.emplacement!,
        nombre_sacs: r.nombre_sacs, receptionniste: r.receptionniste, etat: r.etat || 'Disponible',
      }));
      if (valid.length === 0) { toast.error('Aucune ligne valide'); setImportProgress(null); return; }
      const CHUNK = 500;
      for (let i = 0; i < valid.length; i += CHUNK) {
        const chunk = valid.slice(i, i + CHUNK);
        await batchCreate.mutateAsync(chunk);
        setImportProgress(Math.round(((i + chunk.length) / valid.length) * 100));
      }
      toast.success(`${valid.length} retour(s) importé(s)`);
    } catch (err: any) { toast.error('Erreur: ' + err.message); }
    setImportProgress(null);
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  return (
    <div className="min-h-screen bg-background">
      <header className="no-print sticky top-0 z-10 border-b" style={{ background: 'hsl(var(--header-bg))', color: 'hsl(var(--header-fg))' }}>
        <div className="mx-auto flex h-14 max-w-7xl items-center justify-between px-4">
          <div className="flex items-center gap-2 sm:gap-3">
            <SidebarTrigger className="text-inherit" />
            <div className="flex h-8 w-8 items-center justify-center rounded-md bg-white/20">
              <Package className="h-4 w-4 text-white" />
            </div>
            <h1 className="text-base font-semibold sm:text-lg">Gestion des retours</h1>
          </div>
          <div className="flex items-center gap-2 sm:gap-3">
            <span className="hidden text-sm opacity-80 md:block">{user?.email}</span>
            <ThemeToggle />
            <Button variant="ghost" size="sm" className="btn-press text-inherit hover:bg-white/20" onClick={signOut}>
              <LogOut className="h-4 w-4 sm:mr-2 text-red-400" />
              <span className="hidden sm:inline">Déconnexion</span>
            </Button>
          </div>
        </div>
      </header>

      <main className="mx-auto max-w-7xl space-y-4 p-4 md:space-y-6 md:p-6">
        {/* Title + actions */}
        <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
          <div>
            <h2 className="text-xl font-bold text-foreground sm:text-2xl">Liste des retours</h2>
            <p className="text-sm text-muted-foreground">Gérez les réceptions de retours de colis</p>
          </div>
          <div className="flex flex-wrap gap-2">
            <Button className="btn-press" size="sm" onClick={handleAdd}>
              <Plus className="mr-1 h-4 w-4 text-white" /> Ajouter
            </Button>
            {isAdmin && (
              <Button variant="outline" size="sm" className="btn-press" onClick={() => setRecepDialogOpen(true)}>
                <Users className="mr-1 h-4 w-4 text-blue-500" /> Réceptionnistes
              </Button>
            )}
          </div>
        </div>

        {/* Toolbar */}
        <div className="no-print flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
          <div className="flex flex-1 flex-col gap-2 sm:flex-row sm:gap-3">
            <div className="relative flex-1 sm:max-w-sm">
              <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-blue-500" />
              <Input placeholder="Rechercher..." value={searchQuery} onChange={(e) => setSearchQuery(e.target.value)} className="h-9 pl-9" />
            </div>
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="h-9 w-full sm:w-[150px]">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="Tous">Tous</SelectItem>
                <SelectItem value="Disponible">Disponible</SelectItem>
                <SelectItem value="Retour récupéré">Retour récupéré</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="flex flex-wrap gap-2">
            <Button variant="outline" size="sm" className="btn-press" onClick={() => fileInputRef.current?.click()}>
              <Upload className="mr-1 h-4 w-4 text-green-500" /> Importer
            </Button>
            <input ref={fileInputRef} type="file" accept=".xlsx,.csv" className="hidden" onChange={handleImport} />
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="outline" size="sm" className="btn-press">
                  <Download className="mr-1 h-4 w-4 text-blue-500" /> Exporter
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent>
                <DropdownMenuItem onClick={() => exportExcel(filteredForExport)}><FileSpreadsheet className="mr-2 h-4 w-4 text-green-600" />Excel</DropdownMenuItem>
                <DropdownMenuItem onClick={() => exportCSV(filteredForExport)}><FileText className="mr-2 h-4 w-4 text-blue-600" />CSV</DropdownMenuItem>
                <DropdownMenuItem onClick={() => exportPDF(filteredForExport)}><FileDown className="mr-2 h-4 w-4 text-red-600" />PDF</DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
            <Button variant="outline" size="sm" className="btn-press" onClick={() => setPrintOpen(true)}>
              <Printer className="mr-1 h-4 w-4 text-purple-500" /> Imprimer
            </Button>
          </div>
        </div>

        {importProgress !== null && (
          <div className="space-y-2">
            <div className="flex items-center justify-between text-sm text-muted-foreground">
              <span>Importation...</span><span>{importProgress}%</span>
            </div>
            <Progress value={importProgress} className="h-2" />
          </div>
        )}

        {isLoading ? (
          <div className="card-surface flex h-64 items-center justify-center">
            <p className="text-muted-foreground">Chargement...</p>
          </div>
        ) : (
          <RetourTable data={retours} searchQuery={searchQuery} statusFilter={statusFilter} onEdit={handleEdit} />
        )}
      </main>

      <RetourForm open={formOpen} onOpenChange={setFormOpen} editData={editData} receptionnistes={receptionnistes} />
      <PrintDialog open={printOpen} onOpenChange={setPrintOpen} data={filteredForExport} />
      <ReceptionnistesDialog open={recepDialogOpen} onOpenChange={setRecepDialogOpen} receptionnistes={receptionnistes} onAdd={addReceptionniste} onRemove={removeReceptionniste} />
    </div>
  );
}
