import { useState, useRef } from 'react';
import { SidebarTrigger } from '@/components/ui/sidebar';
import { useAuth } from '@/hooks/useAuth';
import { useRetours, useCreateRetour, useBatchCreateRetours, type RetourColis } from '@/hooks/useRetours';
import { useRealtimeRetours } from '@/hooks/useRealtimeRetours';
import { useReceptionnistes } from '@/hooks/useReceptionnistes';
import { useIsAdmin } from '@/hooks/useAdmin';
import { Progress } from '@/components/ui/progress';
import StatsCards from '@/components/StatsCards';
import RetourTable from '@/components/RetourTable';
import RetourForm from '@/components/RetourForm';
import PrintDialog from '@/components/PrintDialog';
import ReceptionnistesDialog from '@/components/ReceptionnistesDialog';
import ThemeToggle from '@/components/ThemeToggle';
import { exportExcel, exportCSV, exportPDF, importFile } from '@/lib/exportUtils';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import {
  Plus, Download, Upload, Printer, LogOut, Search, FileSpreadsheet, FileText, FileDown, Package, Users,
} from 'lucide-react';
import {
  DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { toast } from 'sonner';

export default function Dashboard() {
  const { signOut, user } = useAuth();
  const { data: retours = [], isLoading } = useRetours();
  useRealtimeRetours();
  const { receptionnistes, addReceptionniste, removeReceptionniste } = useReceptionnistes();
  const { data: isAdmin } = useIsAdmin();
  const createRetour = useCreateRetour();
  const batchCreate = useBatchCreateRetours();
  const [formOpen, setFormOpen] = useState(false);
  const [editData, setEditData] = useState<RetourColis | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState('Tous');
  const [importProgress, setImportProgress] = useState<number | null>(null);
  const [printOpen, setPrintOpen] = useState(false);
  const [recepDialogOpen, setRecepDialogOpen] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const filteredForExport = retours.filter(r => {
    if (statusFilter !== 'Tous' && r.etat !== statusFilter) return false;
    if (searchQuery) {
      const q = searchQuery.toLowerCase();
      if (!r.expediteur.toLowerCase().includes(q) && !(r.etat && r.etat.toLowerCase().includes(q))) return false;
    }
    return true;
  });

  const handleEdit = (retour: RetourColis) => {
    setEditData(retour);
    setFormOpen(true);
  };

  const handleAdd = () => {
    setEditData(null);
    setFormOpen(true);
  };

  const handleImport = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    try {
      setImportProgress(0);
      const rows = await importFile(file);
      const valid = rows.filter(r => r.expediteur && r.quantite && r.emplacement).map(r => ({
        expediteur: r.expediteur!,
        quantite: r.quantite!,
        emplacement: r.emplacement!,
        nombre_sacs: r.nombre_sacs,
        receptionniste: r.receptionniste,
        etat: r.etat || 'Disponible',
      }));
      if (valid.length === 0) {
        toast.error('Aucune ligne valide trouvée dans le fichier');
        setImportProgress(null);
        return;
      }
      const CHUNK = 500;
      for (let i = 0; i < valid.length; i += CHUNK) {
        const chunk = valid.slice(i, i + CHUNK);
        await batchCreate.mutateAsync(chunk);
        setImportProgress(Math.round(((i + chunk.length) / valid.length) * 100));
      }
      toast.success(`${valid.length} retour(s) importé(s) avec succès`);
    } catch (err: any) {
      toast.error('Erreur lors de l\'importation: ' + err.message);
    }
    setImportProgress(null);
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  const handlePrint = () => setPrintOpen(true);

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="no-print sticky top-0 z-10 border-b" style={{ background: 'hsl(var(--header-bg))', color: 'hsl(var(--header-fg))' }}>
        <div className="mx-auto flex h-14 max-w-7xl items-center justify-between px-4">
          <div className="flex items-center gap-3">
            <SidebarTrigger className="text-inherit" />
            <div className="flex h-8 w-8 items-center justify-center rounded-md bg-white/20">
              <Package className="h-4 w-4" />
            </div>
            <h1 className="text-lg font-semibold">Gestion des retours de colis</h1>
          </div>
          <div className="flex items-center gap-3">
            <span className="hidden text-sm opacity-80 sm:block">{user?.email}</span>
            <ThemeToggle />
            <Button variant="ghost" size="sm" className="btn-press text-inherit hover:bg-white/20" onClick={signOut}>
              <LogOut className="mr-2 h-4 w-4" />
              Déconnexion
            </Button>
          </div>
        </div>
      </header>

      <main className="mx-auto max-w-7xl space-y-6 p-4 md:p-6">
        {/* Title + action */}
        <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
          <div>
            <h2 className="text-2xl font-bold text-foreground">Tableau de bord des retours</h2>
            <p className="text-sm text-muted-foreground">Gérez les réceptions de retours de colis</p>
          </div>
          <div className="flex gap-2">
            <Button className="btn-press" onClick={handleAdd}>
              <Plus className="mr-2 h-4 w-4" />
              Ajouter un retour
            </Button>
            {isAdmin && (
              <Button variant="outline" className="btn-press" onClick={() => setRecepDialogOpen(true)}>
                <Users className="mr-2 h-4 w-4" />
                Réceptionnistes
              </Button>
            )}
          </div>
        </div>

        {/* Stats */}
        {!isLoading && <StatsCards data={retours} />}

        {/* Toolbar */}
        <div className="no-print flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
          <div className="flex flex-1 gap-3">
            <div className="relative flex-1 max-w-sm">
              <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
              <Input
                placeholder="Rechercher par expéditeur..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="h-10 pl-9"
              />
            </div>
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="h-10 w-[160px]">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="Tous">Tous</SelectItem>
                <SelectItem value="Disponible">Disponible</SelectItem>
                <SelectItem value="Retour récupéré">Retour récupéré</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="flex gap-2">
            <Button variant="outline" size="sm" className="btn-press" onClick={() => fileInputRef.current?.click()}>
              <Upload className="mr-2 h-4 w-4" />
              Importer
            </Button>
            <input ref={fileInputRef} type="file" accept=".xlsx,.csv" className="hidden" onChange={handleImport} />

            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="outline" size="sm" className="btn-press">
                  <Download className="mr-2 h-4 w-4" />
                  Exporter
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent>
                <DropdownMenuItem onClick={() => exportExcel(filteredForExport)}>
                  <FileSpreadsheet className="mr-2 h-4 w-4" />
                  Excel (.xlsx)
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => exportCSV(filteredForExport)}>
                  <FileText className="mr-2 h-4 w-4" />
                  CSV
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => exportPDF(filteredForExport)}>
                  <FileDown className="mr-2 h-4 w-4" />
                  PDF
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>

            <Button variant="outline" size="sm" className="btn-press" onClick={handlePrint}>
              <Printer className="mr-2 h-4 w-4" />
              Imprimer
            </Button>
          </div>
        </div>

        {/* Import progress */}
        {importProgress !== null && (
          <div className="space-y-2">
            <div className="flex items-center justify-between text-sm text-muted-foreground">
              <span>Importation en cours...</span>
              <span>{importProgress}%</span>
            </div>
            <Progress value={importProgress} className="h-2" />
          </div>
        )}

        {/* Table */}
        {isLoading ? (
          <div className="card-surface flex h-64 items-center justify-center">
            <p className="text-muted-foreground">Chargement...</p>
          </div>
        ) : (
          <RetourTable
            data={retours}
            searchQuery={searchQuery}
            statusFilter={statusFilter}
            onEdit={handleEdit}
          />
        )}
      </main>

      <RetourForm open={formOpen} onOpenChange={setFormOpen} editData={editData} receptionnistes={receptionnistes} />
      <PrintDialog open={printOpen} onOpenChange={setPrintOpen} data={filteredForExport} />
      <ReceptionnistesDialog
        open={recepDialogOpen}
        onOpenChange={setRecepDialogOpen}
        receptionnistes={receptionnistes}
        onAdd={addReceptionniste}
        onRemove={removeReceptionniste}
      />
    </div>
  );
}
