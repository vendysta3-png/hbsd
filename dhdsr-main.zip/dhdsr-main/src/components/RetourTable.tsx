import { useState, useMemo } from 'react';
import {
  useReactTable,
  getCoreRowModel,
  getSortedRowModel,
  getPaginationRowModel,
  getFilteredRowModel,
  flexRender,
  type ColumnDef,
  type SortingState,
} from '@tanstack/react-table';
import { format } from 'date-fns';
import { fr } from 'date-fns/locale';
import { Pencil, Trash2, ArrowUpDown, ChevronLeft, ChevronRight } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import { useDeleteRetour, type RetourColis } from '@/hooks/useRetours';
import { toast } from 'sonner';

interface RetourTableProps {
  data: RetourColis[];
  searchQuery: string;
  statusFilter: string;
  onEdit: (retour: RetourColis) => void;
}

export default function RetourTable({ data, searchQuery, statusFilter, onEdit }: RetourTableProps) {
  const [sorting, setSorting] = useState<SortingState>([]);
  const [deleteId, setDeleteId] = useState<string | null>(null);
  const [selectedRowId, setSelectedRowId] = useState<string | null>(null);
  const deleteRetour = useDeleteRetour();

  const filteredData = useMemo(() => {
    let result = data;
    if (statusFilter && statusFilter !== 'Tous') {
      result = result.filter(r => r.etat === statusFilter);
    }
    if (searchQuery) {
      const q = searchQuery.toLowerCase();
      result = result.filter(r =>
        r.expediteur.toLowerCase().includes(q) ||
        (r.etat && r.etat.toLowerCase().includes(q))
      );
    }
    return result;
  }, [data, searchQuery, statusFilter]);

  const fmt = (d: string | null) => {
    if (!d) return '—';
    return format(new Date(d), 'dd/MM/yyyy HH:mm', { locale: fr });
  };

  const columns: ColumnDef<RetourColis>[] = [
    {
      accessorKey: 'date_heure_saisie',
      header: ({ column }) => (
        <button className="flex items-center gap-1" onClick={() => column.toggleSorting()}>
          Date saisie <ArrowUpDown className="h-3 w-3" />
        </button>
      ),
      cell: ({ row }) => <span className="text-sm">{fmt(row.original.date_heure_saisie)}</span>,
    },
    {
      accessorKey: 'expediteur',
      header: ({ column }) => (
        <button className="flex items-center gap-1" onClick={() => column.toggleSorting()}>
          Expéditeur <ArrowUpDown className="h-3 w-3" />
        </button>
      ),
      cell: ({ row }) => <span className="font-medium">{row.original.expediteur}</span>,
    },
    {
      accessorKey: 'nombre_sacs',
      header: 'Sacs',
      cell: ({ row }) => <span className="font-mono tabular-nums">{row.original.nombre_sacs === -1 ? 'GC' : (row.original.nombre_sacs ?? 0)}</span>,
    },
    {
      accessorKey: 'quantite',
      header: 'Quantité',
      cell: ({ row }) => <span className="font-mono tabular-nums text-right">{row.original.quantite}</span>,
    },
    {
      accessorKey: 'emplacement',
      header: 'Emplac.',
      cell: ({ row }) => <span className="font-mono">{row.original.emplacement}</span>,
    },
    {
      accessorKey: 'receptionniste',
      header: 'Réceptionniste',
    },
    {
      accessorKey: 'etat',
      header: 'État',
      cell: ({ row }) => {
        const etat = row.original.etat;
        return (
          <span className={etat === 'Disponible' ? 'badge-available' : 'badge-recovered'}>
            {etat}
          </span>
        );
      },
    },
    {
      accessorKey: 'date_retour_recupere',
      header: 'Date récupéré',
      cell: ({ row }) => <span className="text-sm">{fmt(row.original.date_retour_recupere)}</span>,
    },
    {
      id: 'actions',
      header: 'Actions',
      cell: ({ row }) => (
        <div className="flex gap-1">
          <Button variant="ghost" size="icon" className="h-8 w-8 btn-press" onClick={() => onEdit(row.original)}>
            <Pencil className="h-4 w-4 text-blue-500" />
          </Button>
          <Button variant="ghost" size="icon" className="h-8 w-8 btn-press text-destructive" onClick={() => setDeleteId(row.original.id)}>
            <Trash2 className="h-4 w-4 text-red-500" />
          </Button>
        </div>
      ),
    },
  ];

  const table = useReactTable({
    data: filteredData,
    columns,
    state: { sorting },
    onSortingChange: setSorting,
    getCoreRowModel: getCoreRowModel(),
    getSortedRowModel: getSortedRowModel(),
    getPaginationRowModel: getPaginationRowModel(),
    getFilteredRowModel: getFilteredRowModel(),
    initialState: { pagination: { pageSize: 10 } },
  });

  const handleDelete = async () => {
    if (!deleteId) return;
    try {
      await deleteRetour.mutateAsync(deleteId);
      toast.success('Retour supprimé');
    } catch (err: any) {
      toast.error(err.message);
    }
    setDeleteId(null);
  };

  return (
    <div className="card-surface overflow-hidden">
      <div className="overflow-x-auto">
        <table className="w-full text-sm">
          <thead>
            {table.getHeaderGroups().map(hg => (
              <tr key={hg.id} className="border-b bg-muted/50">
                {hg.headers.map(h => (
                  <th key={h.id} className="px-3 py-3 text-left text-xs font-medium uppercase tracking-wider text-muted-foreground">
                    {h.isPlaceholder ? null : flexRender(h.column.columnDef.header, h.getContext())}
                  </th>
                ))}
              </tr>
            ))}
          </thead>
          <tbody>
            {table.getRowModel().rows.length === 0 ? (
              <tr>
                <td colSpan={columns.length} className="py-12 text-center text-muted-foreground">
                  Aucun retour trouvé. Commencez par en enregistrer un.
                </td>
              </tr>
            ) : (
              table.getRowModel().rows.map(row => (
                <tr
                  key={row.id}
                  className={`border-b last:border-0 cursor-pointer transition-colors ${selectedRowId === row.original.id ? 'bg-blue-100 dark:bg-blue-900/30' : 'table-row-hover'}`}
                  style={{ height: 48 }}
                  onClick={() => setSelectedRowId(selectedRowId === row.original.id ? null : row.original.id)}
                >
                  {row.getVisibleCells().map(cell => (
                    <td key={cell.id} className="px-3 py-2">
                      {flexRender(cell.column.columnDef.cell, cell.getContext())}
                    </td>
                  ))}
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      {/* Pagination */}
      <div className="flex items-center justify-between border-t px-4 py-3">
        <div className="flex items-center gap-2 text-sm text-muted-foreground">
          <span>Lignes par page:</span>
          <Select
            value={String(table.getState().pagination.pageSize)}
            onValueChange={(v) => table.setPageSize(Number(v))}
          >
            <SelectTrigger className="h-8 w-[70px]">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {[10, 25, 50, 100].map(s => (
                <SelectItem key={s} value={String(s)}>{s}</SelectItem>
              ))}
            </SelectContent>
          </Select>
          <span>
            {table.getState().pagination.pageIndex * table.getState().pagination.pageSize + 1}–
            {Math.min(
              (table.getState().pagination.pageIndex + 1) * table.getState().pagination.pageSize,
              filteredData.length
            )}{' '}
            sur {filteredData.length}
          </span>
        </div>
        <div className="flex gap-1">
          <Button variant="outline" size="icon" className="h-8 w-8" disabled={!table.getCanPreviousPage()} onClick={() => table.previousPage()}>
            <ChevronLeft className="h-4 w-4 text-blue-500" />
          </Button>
          <Button variant="outline" size="icon" className="h-8 w-8" disabled={!table.getCanNextPage()} onClick={() => table.nextPage()}>
            <ChevronRight className="h-4 w-4 text-blue-500" />
          </Button>
        </div>
      </div>

      {/* Delete confirmation */}
      <AlertDialog open={!!deleteId} onOpenChange={(open) => !open && setDeleteId(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Confirmer la suppression</AlertDialogTitle>
            <AlertDialogDescription>
              Cette action est irréversible. Voulez-vous vraiment supprimer ce retour ?
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Annuler</AlertDialogCancel>
            <AlertDialogAction onClick={handleDelete} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">
              Supprimer
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
