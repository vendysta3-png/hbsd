import { useState, useRef } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Checkbox } from '@/components/ui/checkbox';
import { Label } from '@/components/ui/label';
import { format } from 'date-fns';
import { fr } from 'date-fns/locale';
import type { RetourColis } from '@/hooks/useRetours';

const ALL_COLUMNS = [
  { key: 'id', label: 'ID' },
  { key: 'date_heure_saisie', label: 'Date saisie' },
  { key: 'expediteur', label: 'Expéditeur' },
  { key: 'nombre_sacs', label: 'Sacs' },
  { key: 'quantite', label: 'Quantité' },
  { key: 'emplacement', label: 'Emplacement' },
  { key: 'receptionniste', label: 'Réceptionniste' },
  { key: 'etat', label: 'État' },
  { key: 'date_retour_recupere', label: 'Date récupéré' },
] as const;

type ColKey = typeof ALL_COLUMNS[number]['key'];

interface PrintDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  data: RetourColis[];
}

export default function PrintDialog({ open, onOpenChange, data }: PrintDialogProps) {
  const [selectedCols, setSelectedCols] = useState<Set<ColKey>>(new Set(ALL_COLUMNS.map(c => c.key)));
  const [selectedRows, setSelectedRows] = useState<Set<string>>(new Set(data.map(r => r.id)));
  const printRef = useRef<HTMLDivElement>(null);

  const toggleCol = (key: ColKey) => {
    const next = new Set(selectedCols);
    next.has(key) ? next.delete(key) : next.add(key);
    setSelectedCols(next);
  };

  const toggleAllRows = () => {
    setSelectedRows(selectedRows.size === data.length ? new Set() : new Set(data.map(r => r.id)));
  };

  const toggleRow = (id: string) => {
    const next = new Set(selectedRows);
    next.has(id) ? next.delete(id) : next.add(id);
    setSelectedRows(next);
  };

  const fmt = (d: string | null) => {
    if (!d) return '—';
    return format(new Date(d), 'dd/MM/yyyy HH:mm', { locale: fr });
  };

  const getCellValue = (row: RetourColis, key: ColKey): string => {
    switch (key) {
      case 'id': return row.id.slice(0, 8);
      case 'date_heure_saisie': return fmt(row.date_heure_saisie);
      case 'date_retour_recupere': return fmt(row.date_retour_recupere);
      case 'nombre_sacs': return String(row.nombre_sacs ?? 0);
      default: return String((row as any)[key] ?? '—');
    }
  };

  const handlePrint = () => {
    const printWindow = window.open('', '_blank');
    if (!printWindow) return;

    const cols = ALL_COLUMNS.filter(c => selectedCols.has(c.key));
    const rows = data.filter(r => selectedRows.has(r.id));

    printWindow.document.write(`
      <html><head><title>L-RETOUR - Impression</title>
      <style>
        body { font-family: Arial, sans-serif; margin: 20px; }
        h2 { text-align: center; margin-bottom: 16px; }
        table { width: 100%; border-collapse: collapse; font-size: 11px; }
        th, td { border: 1px solid #ccc; padding: 6px 8px; text-align: left; }
        th { background: #f5f5f5; font-weight: 600; }
        .meta { text-align: center; color: #666; font-size: 12px; margin-bottom: 12px; }
      </style></head><body>
      <h2>L-RETOUR — Liste des retours</h2>
      <p class="meta">Imprimé le ${format(new Date(), 'dd/MM/yyyy HH:mm', { locale: fr })} — ${rows.length} ligne(s)</p>
      <table><thead><tr>${cols.map(c => `<th>${c.label}</th>`).join('')}</tr></thead>
      <tbody>${rows.map(r => `<tr>${cols.map(c => `<td>${getCellValue(r, c.key)}</td>`).join('')}</tr>`).join('')}</tbody></table>
      </body></html>
    `);
    printWindow.document.close();
    printWindow.print();
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-lg max-h-[80vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Impression personnalisée</DialogTitle>
        </DialogHeader>

        <div className="space-y-4">
          {/* Column selection */}
          <div>
            <p className="mb-2 text-sm font-medium">Colonnes à imprimer</p>
            <div className="grid grid-cols-2 gap-2">
              {ALL_COLUMNS.map(col => (
                <Label key={col.key} className="flex items-center gap-2 text-sm cursor-pointer">
                  <Checkbox
                    checked={selectedCols.has(col.key)}
                    onCheckedChange={() => toggleCol(col.key)}
                  />
                  {col.label}
                </Label>
              ))}
            </div>
          </div>

          {/* Row selection */}
          <div>
            <div className="mb-2 flex items-center justify-between">
              <p className="text-sm font-medium">Lignes à imprimer ({selectedRows.size}/{data.length})</p>
              <Button variant="ghost" size="sm" onClick={toggleAllRows}>
                {selectedRows.size === data.length ? 'Tout désélectionner' : 'Tout sélectionner'}
              </Button>
            </div>
            <div className="max-h-48 overflow-y-auto rounded border p-2 space-y-1">
              {data.map(r => (
                <Label key={r.id} className="flex items-center gap-2 text-sm cursor-pointer">
                  <Checkbox
                    checked={selectedRows.has(r.id)}
                    onCheckedChange={() => toggleRow(r.id)}
                  />
                  <span className="truncate">{r.expediteur} — {r.etat}</span>
                </Label>
              ))}
            </div>
          </div>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>Annuler</Button>
          <Button onClick={handlePrint} disabled={selectedCols.size === 0 || selectedRows.size === 0}>
            Imprimer ({selectedRows.size} lignes)
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
