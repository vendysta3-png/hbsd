import { forwardRef } from 'react';
import { Package, Clock, CheckCircle2, CalendarCheck } from 'lucide-react';
import type { RetourColis } from '@/hooks/useRetours';

interface StatsCardsProps {
  data: RetourColis[];
}

const StatsCards = forwardRef<HTMLDivElement, StatsCardsProps>(function StatsCards({ data }, ref) {
  const total = data.length;
  const disponible = data.filter(r => r.etat === 'Disponible').length;
  const recupere = data.filter(r => r.etat === 'Retour récupéré').length;

  const today = new Date().toDateString();
  const recupereToday = data.filter(r => {
    if (r.etat !== 'Retour récupéré' || !r.date_retour_recupere) return false;
    return new Date(r.date_retour_recupere).toDateString() === today;
  }).length;

  const stats = [
    { label: 'Total retours', value: total, icon: Package, iconColor: 'text-blue-500', className: 'card-surface p-5 stat-total' },
    { label: 'Disponible', value: disponible, icon: Clock, iconColor: 'text-orange-500', className: 'card-surface p-5 stat-available' },
    { label: 'Récupéré', value: recupere, icon: CheckCircle2, iconColor: 'text-green-500', className: 'card-surface p-5 stat-recovered' },
    { label: 'Récupéré aujourd\'hui', value: recupereToday, icon: CalendarCheck, iconColor: 'text-purple-500', className: 'card-surface p-5' },
  ];

  return (
    <div ref={ref} className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
      {stats.map((s) => (
        <div key={s.label} className={s.className}>
          <div className="flex items-center justify-between">
            <p className="text-sm font-medium opacity-80">{s.label}</p>
            <s.icon className={`h-5 w-5 ${s.iconColor}`} />
          </div>
          <p className="mt-2 text-3xl font-bold tabular-nums">{s.value}</p>
        </div>
      ))}
    </div>
  );
});

export default StatsCards;
