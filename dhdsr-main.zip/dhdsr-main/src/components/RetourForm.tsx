import { useEffect } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { Sheet, SheetContent, SheetHeader, SheetTitle } from '@/components/ui/sheet';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useCreateRetour, useUpdateRetour, type RetourColis } from '@/hooks/useRetours';
import { Checkbox } from '@/components/ui/checkbox';
import { toast } from 'sonner';

const schema = z.object({
  date_heure_saisie: z.string().min(1, 'Requis'),
  expediteur: z.string().min(1, 'Requis'),
  grands_colis: z.boolean(),
  nombre_sacs: z.number().min(0),
  quantite: z.string().min(1, 'Requis'),
  emplacement: z.string().min(1, 'Requis'),
  receptionniste: z.string().min(1, 'Requis'),
  etat: z.string().min(1, 'Requis'),
  date_retour_recupere: z.string().optional(),
});

type FormData = z.infer<typeof schema>;

const emplacements = [
  ...Array.from({ length: 50 }, (_, i) => String(i + 1)),
  ...Array.from({ length: 26 }, (_, i) => String.fromCharCode(65 + i)),
];

interface RetourFormProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  editData?: RetourColis | null;
  receptionnistes?: string[];
}

export default function RetourForm({ open, onOpenChange, editData, receptionnistes = ['Mourad', 'Rahim', 'Amine', 'Salim'] }: RetourFormProps) {
  const createRetour = useCreateRetour();
  const updateRetour = useUpdateRetour();

  const now = () => new Date().toISOString().slice(0, 16);

  const { register, handleSubmit, setValue, watch, reset, formState: { errors } } = useForm<FormData>({
    resolver: zodResolver(schema),
    defaultValues: {
      date_heure_saisie: now(),
      expediteur: '',
      grands_colis: false,
      nombre_sacs: 1,
      quantite: '',
      emplacement: '',
      receptionniste: '',
      etat: 'Disponible',
      date_retour_recupere: '',
    },
  });

  const etat = watch('etat');

  // Auto-fill date_retour_recupere when état changes to "Retour récupéré"
  useEffect(() => {
    if (etat === 'Retour récupéré') {
      const current = watch('date_retour_recupere');
      if (!current) {
        setValue('date_retour_recupere', new Date().toISOString().slice(0, 16));
      }
    }
  }, [etat, setValue, watch]);

  useEffect(() => {
    if (open) {
      if (editData) {
        const isGC = editData.nombre_sacs === -1;
        reset({
          date_heure_saisie: editData.date_heure_saisie ? new Date(editData.date_heure_saisie).toISOString().slice(0, 16) : now(),
          expediteur: editData.expediteur,
          grands_colis: isGC,
          nombre_sacs: isGC ? 1 : (editData.nombre_sacs ?? 1),
          quantite: editData.quantite,
          emplacement: editData.emplacement,
          receptionniste: editData.receptionniste ?? '',
          etat: editData.etat ?? 'Disponible',
          date_retour_recupere: editData.date_retour_recupere ? new Date(editData.date_retour_recupere).toISOString().slice(0, 16) : '',
        });
      } else {
        reset({
          date_heure_saisie: now(),
          expediteur: '',
          grands_colis: false,
          nombre_sacs: 1,
          quantite: '',
          emplacement: '',
          receptionniste: '',
          etat: 'Disponible',
          date_retour_recupere: '',
        });
      }
    }
  }, [open, editData, reset]);

  const onSubmit = async (data: FormData) => {
    try {
      const payload = {
        date_heure_saisie: new Date(data.date_heure_saisie).toISOString(),
        expediteur: data.expediteur,
        nombre_sacs: data.grands_colis ? -1 : data.nombre_sacs,
        quantite: data.quantite,
        emplacement: data.emplacement,
        receptionniste: data.receptionniste,
        etat: data.etat,
        date_retour_recupere: data.etat === 'Retour récupéré' && data.date_retour_recupere
          ? new Date(data.date_retour_recupere).toISOString()
          : null,
      };

      if (editData) {
        await updateRetour.mutateAsync({ id: editData.id, ...payload });
        toast.success('Retour mis à jour avec succès');
      } else {
        await createRetour.mutateAsync(payload);
        toast.success('Retour enregistré avec succès');
      }
      onOpenChange(false);
    } catch (err: any) {
      toast.error(err.message || 'Erreur lors de l\'enregistrement');
    }
  };

  return (
    <Sheet open={open} onOpenChange={onOpenChange}>
      <SheetContent className="w-full overflow-y-auto sm:max-w-lg">
        <SheetHeader>
          <SheetTitle>{editData ? 'Modifier le retour' : 'Enregistrer un retour'}</SheetTitle>
        </SheetHeader>
        <form onSubmit={handleSubmit(onSubmit)} className="mt-6 space-y-5">
          <div className="space-y-2">
            <Label>Date et heure saisie</Label>
            <Input type="datetime-local" {...register('date_heure_saisie')} className="h-11" />
            {errors.date_heure_saisie && <p className="text-xs text-destructive">{errors.date_heure_saisie.message}</p>}
          </div>

          <div className="space-y-2">
            <Label>Expéditeur</Label>
            <Input {...register('expediteur')} placeholder="Nom de l'expéditeur" className="h-11" />
            {errors.expediteur && <p className="text-xs text-destructive">{errors.expediteur.message}</p>}
          </div>

          <div className="flex items-center gap-2 py-1">
            <Checkbox
              id="grands_colis"
              checked={watch('grands_colis')}
              onCheckedChange={(checked) => setValue('grands_colis', !!checked)}
            />
            <Label htmlFor="grands_colis" className="cursor-pointer">Grands colis</Label>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2" style={{ opacity: watch('grands_colis') ? 0.4 : 1, pointerEvents: watch('grands_colis') ? 'none' : 'auto' }}>
              <Label>Nombre de sacs</Label>
              <Input type="number" min={0} {...register('nombre_sacs', { valueAsNumber: true })} className="h-11" />
            </div>
            <div className="space-y-2">
              <Label>Quantité</Label>
              <Input {...register('quantite')} placeholder="Ex: 12, 10+, 15-" className="h-11 font-mono" />
              {errors.quantite && <p className="text-xs text-destructive">{errors.quantite.message}</p>}
            </div>
          </div>

          <div className="space-y-2">
            <Label>Emplacement</Label>
            <Select onValueChange={(v) => setValue('emplacement', v)} value={watch('emplacement')}>
              <SelectTrigger className="h-11">
                <SelectValue placeholder="Choisir un emplacement" />
              </SelectTrigger>
              <SelectContent>
                {emplacements.map(e => (
                  <SelectItem key={e} value={e}>{e}</SelectItem>
                ))}
              </SelectContent>
            </Select>
            {errors.emplacement && <p className="text-xs text-destructive">{errors.emplacement.message}</p>}
          </div>

          <div className="space-y-2">
            <Label>Réceptionniste</Label>
            <Select onValueChange={(v) => setValue('receptionniste', v)} value={watch('receptionniste')}>
              <SelectTrigger className="h-11">
                <SelectValue placeholder="Choisir un réceptionniste" />
              </SelectTrigger>
              <SelectContent>
                {receptionnistes.map(r => (
                  <SelectItem key={r} value={r}>{r}</SelectItem>
                ))}
              </SelectContent>
            </Select>
            {errors.receptionniste && <p className="text-xs text-destructive">{errors.receptionniste.message}</p>}
          </div>

          <div className="space-y-2">
            <Label>État</Label>
            <Select onValueChange={(v) => setValue('etat', v)} value={etat}>
              <SelectTrigger className="h-11">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="Disponible">Disponible</SelectItem>
                <SelectItem value="Retour récupéré">Retour récupéré</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div
            className="space-y-2 transition-opacity duration-200"
            style={{
              opacity: etat === 'Retour récupéré' ? 1 : 0.4,
              pointerEvents: etat === 'Retour récupéré' ? 'auto' : 'none',
            }}
          >
            <Label>Date et heure retour récupéré</Label>
            <Input type="datetime-local" {...register('date_retour_recupere')} className="h-11" />
          </div>

          <div className="flex gap-3 pt-4">
            <Button type="button" variant="outline" className="btn-press flex-1" onClick={() => onOpenChange(false)}>
              Annuler
            </Button>
            <Button type="submit" className="btn-press flex-1" disabled={createRetour.isPending || updateRetour.isPending}>
              {editData ? 'Mettre à jour' : 'Enregistrer'}
            </Button>
          </div>
        </form>
      </SheetContent>
    </Sheet>
  );
}
