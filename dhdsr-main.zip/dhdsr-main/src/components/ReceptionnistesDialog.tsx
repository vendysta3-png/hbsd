import { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Plus, X } from 'lucide-react';

interface Props {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  receptionnistes: string[];
  onAdd: (name: string) => void;
  onRemove: (name: string) => void;
}

export default function ReceptionnistesDialog({ open, onOpenChange, receptionnistes, onAdd, onRemove }: Props) {
  const [newName, setNewName] = useState('');

  const handleAdd = () => {
    if (newName.trim()) {
      onAdd(newName.trim());
      setNewName('');
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-sm">
        <DialogHeader>
          <DialogTitle>Gérer les réceptionnistes</DialogTitle>
        </DialogHeader>
        <div className="space-y-4">
          <div className="flex gap-2">
            <Input
              placeholder="Nouveau réceptionniste"
              value={newName}
              onChange={e => setNewName(e.target.value)}
              onKeyDown={e => e.key === 'Enter' && handleAdd()}
              className="h-10"
            />
            <Button size="sm" className="h-10 px-3" onClick={handleAdd} disabled={!newName.trim()}>
              <Plus className="h-4 w-4" />
            </Button>
          </div>
          <div className="max-h-60 space-y-1 overflow-y-auto">
            {receptionnistes.map(name => (
              <div key={name} className="flex items-center justify-between rounded-md border px-3 py-2 text-sm">
                <span>{name}</span>
                <button onClick={() => onRemove(name)} className="text-muted-foreground hover:text-destructive">
                  <X className="h-4 w-4" />
                </button>
              </div>
            ))}
            {receptionnistes.length === 0 && (
              <p className="text-sm text-muted-foreground text-center py-4">Aucun réceptionniste</p>
            )}
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
