import * as XLSX from 'xlsx';
import { saveAs } from 'file-saver';
import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';
import { format } from 'date-fns';
import { fr } from 'date-fns/locale';
import type { RetourColis } from '@/hooks/useRetours';

const fmt = (d: string | null) => {
  if (!d) return '';
  return format(new Date(d), 'dd/MM/yyyy HH:mm', { locale: fr });
};

const headers = ['ID', 'Date saisie', 'Expéditeur', 'Sacs', 'Quantité', 'Emplacement', 'Réceptionniste', 'État', 'Date récupéré'];

function toRows(data: RetourColis[]) {
  return data.map(r => [
    r.id.slice(0, 8),
    fmt(r.date_heure_saisie),
    r.expediteur,
    r.nombre_sacs ?? 0,
    r.quantite,
    r.emplacement,
    r.receptionniste ?? '',
    r.etat ?? '',
    fmt(r.date_retour_recupere),
  ]);
}

export function exportExcel(data: RetourColis[]) {
  const ws = XLSX.utils.aoa_to_sheet([headers, ...toRows(data)]);
  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, 'Retours');
  const buf = XLSX.write(wb, { bookType: 'xlsx', type: 'array' });
  saveAs(new Blob([buf]), `retours_${format(new Date(), 'yyyyMMdd')}.xlsx`);
}

export function exportCSV(data: RetourColis[]) {
  const ws = XLSX.utils.aoa_to_sheet([headers, ...toRows(data)]);
  const csv = XLSX.utils.sheet_to_csv(ws);
  saveAs(new Blob([csv], { type: 'text/csv;charset=utf-8' }), `retours_${format(new Date(), 'yyyyMMdd')}.csv`);
}

export function exportPDF(data: RetourColis[]) {
  const doc = new jsPDF({ orientation: 'landscape' });
  doc.setFontSize(16);
  doc.text('Tableau des retours de colis', 14, 15);
  doc.setFontSize(10);
  doc.text(`Exporté le ${format(new Date(), 'dd/MM/yyyy HH:mm', { locale: fr })}`, 14, 22);

  autoTable(doc, {
    head: [headers],
    body: toRows(data) as any,
    startY: 28,
    styles: { fontSize: 8 },
    headStyles: { fillColor: [59, 130, 246] },
  });

  doc.save(`retours_${format(new Date(), 'yyyyMMdd')}.pdf`);
}

export function importFile(file: File): Promise<Partial<RetourColis>[]> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const data = new Uint8Array(e.target!.result as ArrayBuffer);
        const workbook = XLSX.read(data, { type: 'array' });
        const sheet = workbook.Sheets[workbook.SheetNames[0]];
        const json = XLSX.utils.sheet_to_json<Record<string, any>>(sheet);

        const mapped = json.map((row) => {
          const r: Partial<RetourColis> = {};
          // Try to map common column names
          for (const [key, val] of Object.entries(row)) {
            const k = key.toLowerCase().trim();
            if (k.includes('expediteur') || k.includes('expéditeur')) r.expediteur = String(val);
            if (k.includes('sac')) r.nombre_sacs = Number(val) || 1;
            if (k.includes('quantit')) r.quantite = String(val);
            if (k.includes('emplacement')) r.emplacement = String(val);
            if (k.includes('réceptionniste') || k.includes('receptionniste')) r.receptionniste = String(val);
            if (k.includes('etat') || k.includes('état')) r.etat = String(val);
          }
          return r;
        });
        resolve(mapped);
      } catch (err) {
        reject(err);
      }
    };
    reader.onerror = reject;
    reader.readAsArrayBuffer(file);
  });
}
