import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders })
  }

  try {
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!
    const serviceRoleKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!

    // Verify caller is admin
    const authHeader = req.headers.get('Authorization')!
    const callerClient = createClient(supabaseUrl, Deno.env.get('SUPABASE_ANON_KEY')!, {
      global: { headers: { Authorization: authHeader } },
    })
    const { data: { user: caller } } = await callerClient.auth.getUser()
    if (!caller) {
      return new Response(JSON.stringify({ error: 'Non authentifié' }), { status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' } })
    }

    const adminClient = createClient(supabaseUrl, serviceRoleKey)
    const { data: roleCheck } = await adminClient.from('user_roles').select('role').eq('user_id', caller.id).eq('role', 'admin').maybeSingle()
    if (!roleCheck) {
      return new Response(JSON.stringify({ error: 'Accès refusé' }), { status: 403, headers: { ...corsHeaders, 'Content-Type': 'application/json' } })
    }

    const { action, ...body } = await req.json()

    if (action === 'create') {
      const { email, password, role } = body
      const { data: newUser, error } = await adminClient.auth.admin.createUser({
        email,
        password,
        email_confirm: true,
      })
      if (error) throw error

      await adminClient.from('user_roles').insert({ user_id: newUser.user.id, role: role || 'user' })
      return new Response(JSON.stringify({ user: newUser.user }), { headers: { ...corsHeaders, 'Content-Type': 'application/json' } })
    }

    if (action === 'list') {
      const { data: { users }, error } = await adminClient.auth.admin.listUsers()
      if (error) throw error
      const { data: roles } = await adminClient.from('user_roles').select('*')
      const enriched = users.map(u => ({
        id: u.id,
        email: u.email,
        created_at: u.created_at,
        role: roles?.find(r => r.user_id === u.id)?.role || 'user',
      }))
      return new Response(JSON.stringify({ users: enriched }), { headers: { ...corsHeaders, 'Content-Type': 'application/json' } })
    }

    if (action === 'update') {
      const { user_id, email, password, role } = body
      if (user_id === caller.id) {
        return new Response(JSON.stringify({ error: 'Utilisez votre profil pour modifier votre propre compte' }), { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } })
      }
      const updatePayload: Record<string, any> = {}
      if (email) updatePayload.email = email
      if (password) updatePayload.password = password
      if (Object.keys(updatePayload).length > 0) {
        const { error } = await adminClient.auth.admin.updateUserById(user_id, updatePayload)
        if (error) throw error
      }
      if (role) {
        await adminClient.from('user_roles').upsert({ user_id, role }, { onConflict: 'user_id,role' })
        // Remove old roles if changing
        await adminClient.from('user_roles').delete().eq('user_id', user_id).neq('role', role)
      }
      return new Response(JSON.stringify({ success: true }), { headers: { ...corsHeaders, 'Content-Type': 'application/json' } })
    }

    if (action === 'delete') {
      const { user_id } = body
      if (user_id === caller.id) {
        return new Response(JSON.stringify({ error: 'Impossible de supprimer votre propre compte' }), { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } })
      }
      const { error } = await adminClient.auth.admin.deleteUser(user_id)
      if (error) throw error
      return new Response(JSON.stringify({ success: true }), { headers: { ...corsHeaders, 'Content-Type': 'application/json' } })
    }

    if (action === 'clear_data') {
      const { error } = await adminClient.from('retours_colis').delete().neq('id', '00000000-0000-0000-0000-000000000000')
      if (error) throw error
      return new Response(JSON.stringify({ success: true }), { headers: { ...corsHeaders, 'Content-Type': 'application/json' } })
    }

    if (action === 'backup') {
      const { data, error } = await adminClient.from('retours_colis').select('*')
      if (error) throw error
      return new Response(JSON.stringify({ data }), { headers: { ...corsHeaders, 'Content-Type': 'application/json' } })
    }

    if (action === 'restore') {
      const { records } = body
      // Clear existing
      await adminClient.from('retours_colis').delete().neq('id', '00000000-0000-0000-0000-000000000000')
      // Insert restored data
      if (records && records.length > 0) {
        const CHUNK = 500
        for (let i = 0; i < records.length; i += CHUNK) {
          const chunk = records.slice(i, i + CHUNK)
          const { error } = await adminClient.from('retours_colis').insert(chunk)
          if (error) throw error
        }
      }
      return new Response(JSON.stringify({ success: true, count: records?.length || 0 }), { headers: { ...corsHeaders, 'Content-Type': 'application/json' } })
    }

    return new Response(JSON.stringify({ error: 'Action inconnue' }), { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } })
  } catch (err: any) {
    return new Response(JSON.stringify({ error: err.message }), { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } })
  }
})
