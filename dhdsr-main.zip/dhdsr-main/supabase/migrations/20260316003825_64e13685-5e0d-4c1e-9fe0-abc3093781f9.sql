
-- Create the retours_colis table
CREATE TABLE public.retours_colis (
  id uuid DEFAULT gen_random_uuid() PRIMARY KEY,
  date_heure_saisie timestamp with time zone DEFAULT now() NOT NULL,
  expediteur text NOT NULL,
  nombre_sacs integer DEFAULT 1,
  quantite text NOT NULL,
  emplacement text NOT NULL,
  receptionniste text CHECK (receptionniste IN ('Mourad', 'Rahim', 'Amine', 'Salim')),
  etat text DEFAULT 'Disponible' CHECK (etat IN ('Disponible', 'Retour récupéré')),
  date_retour_recupere timestamp with time zone,
  created_at timestamp with time zone DEFAULT now(),
  updated_at timestamp with time zone DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.retours_colis ENABLE ROW LEVEL SECURITY;

-- Policies: all authenticated users can CRUD (internal tool)
CREATE POLICY "Authenticated users can view all retours" ON public.retours_colis
  FOR SELECT TO authenticated USING (true);

CREATE POLICY "Authenticated users can insert retours" ON public.retours_colis
  FOR INSERT TO authenticated WITH CHECK (true);

CREATE POLICY "Authenticated users can update retours" ON public.retours_colis
  FOR UPDATE TO authenticated USING (true);

CREATE POLICY "Authenticated users can delete retours" ON public.retours_colis
  FOR DELETE TO authenticated USING (true);

-- Timestamp trigger
CREATE OR REPLACE FUNCTION public.update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SET search_path = public;

CREATE TRIGGER update_retours_colis_updated_at
  BEFORE UPDATE ON public.retours_colis
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
